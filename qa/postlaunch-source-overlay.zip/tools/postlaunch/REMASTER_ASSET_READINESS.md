# Remastered Graphics — exact source-based art pipeline (NOT FINISHED)

This WIP preserves Classic as the baseline, and prevents prototype-only visuals
being advertised as a full remaster. Pixel dimensions of tile strip and character
sheets drive the mapping, NOT upscaling by arbitrary percentages.

- Primary characters/enemies share `data/chars_50x50.png` (600x640): **12 columns × 8 rows, 50×80 source-frame geometry**, despite its historical filename. Replacing it requires all frames to align; game physics use independent 10×41 or similar collision geometry and must remain untouched.
- Three main chapter tile strips are 180×10: 18 tile columns, 10×10 each. All variants must preserve exact RGBA alpha mask.
- GraphicsMode currently switches ONLY three decorative tile strips; it is a **preview**, not a full remaster.
- All other source graphics must be inventoried and replaced at native pixel geometry, including level backgrounds, props, collisions with sprite offsets, character/enemy animations, UI, and transitions.
- Gameplay screenshots and Google Play images must be genuine game captures, not concept renders or fake remastered scenes.
- Before any remaster release, review every chapter's representative Android frame and animation sequence. Never replace frame sheet assets before checking frame-index layout and transparency.

See `qa/postlaunch/REMASTER_ASSET_PRIORITY.csv` for an exact actionable source-image census produced from current source embeds. This is a planning instrument, not a claim that 76 art assets have been remastered.
