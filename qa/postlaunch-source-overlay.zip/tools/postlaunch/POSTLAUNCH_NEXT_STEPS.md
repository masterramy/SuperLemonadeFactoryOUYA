# Four-track development — next runtime boundary

1. The owner has already compiled the prior post-launch SWF successfully using AIR 51.3.4.3 and JDK 17, exit=0, SHA256 826a505c... . The new changes after that **need a fresh compile**, not an assumption that the old receipt covers them.
2. Controller: Android hat/D-pad axes added. Independent disposable QA package builder `BUILD_DISPOSABLE_TEST_APK.bat` creates **com.ramybaheeg.slfport.dev**, NOT the Production app, from a newly compiled SWF. This builder itself is not yet tested on Windows. DO NOT run production signer; do not install a test package with the Play app ID.
3. Cloud: strict snapshot categories, missing/extra categories and typed schema fail closed; Python contract simulations are independent mirror checks, NOT AIR service sync. Await Google Play Games ID, native extension and account OAuth; no cloud credentials required for local work.
4. Graphics: 109 source-used image assets have been prioritized, with 5 critical (including the shared 600x640, 50x80-frame character sheet). Three world tile prototypes only; remaster is not complete. No fake screenshots.
5. Trailer: ADB gameplay capture now finds Android SDK adb automatically, requires the live game process and saves a SHA provenance receipt. No recorded genuine gameplay exists yet; the assembly script refuses fewer than two videos.
6. v1.9.1 Production submission and public corresponding source are untouched and separate.
