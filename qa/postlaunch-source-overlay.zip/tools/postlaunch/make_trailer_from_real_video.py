#!/usr/bin/env python3
"""Compile REAL device gameplay clips into a 16:9 trailer, no simulated footage.

Requires ffmpeg/ffprobe and 2+ videos actually recorded from the game.
No generated/AI gameplay frames, no speedup/slowdown, no invented mechanics.
"""
import argparse, shutil, subprocess, sys, pathlib, tempfile

p = argparse.ArgumentParser()
p.add_argument('clips', nargs='+', type=pathlib.Path)
p.add_argument('--output', default='SUPER_LIMEADE_FACTORY_REAL_GAMEPLAY_TRAILER.mp4')
p.add_argument('--music', type=pathlib.Path, default=None, help='optional authorized soundtrack')
p.add_argument('--seconds-per-clip', type=int, default=12)
a = p.parse_args()
if len(a.clips) < 2: p.error('At least two REAL gameplay recordings are required.')
for prog in ('ffmpeg','ffprobe'):
    if not shutil.which(prog): p.error(f'{prog} not installed.')
for c in a.clips:
    if not c.is_file() or c.stat().st_size < 10000: p.error(f'Invalid video file: {c}')
    r = subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height','-of','default=noprint_wrappers=1',str(c)],capture_output=True,text=True)
    if r.returncode or 'width=' not in r.stdout:p.error(f'Not decodable as video: {c}')
with tempfile.TemporaryDirectory() as td:
    tmp=pathlib.Path(td)
    rendered=[]
    for i,c in enumerate(a.clips):
        out=tmp/f'segment_{i}.mp4'
        cmd=['ffmpeg','-y','-loglevel','error','-i',str(c),'-t',str(a.seconds_per_clip),'-vf',
            'fps=30,scale=1920:1080:force_original_aspect_ratio=decrease:flags=neighbor,pad=1920:1080:(ow-iw)/2:(oh-ih)/2,setsar=1',
            '-an','-c:v','libx264','-pix_fmt','yuv420p','-preset','medium','-crf','20',str(out)]
        subprocess.run(cmd,check=True);rendered.append(out)
    inputs=[]
    for item in rendered:inputs.extend(['-i',str(item)])
    out=pathlib.Path(a.output).resolve()
    filt=''.join(f'[{i}:v:0]' for i in range(len(rendered)))+f'concat=n={len(rendered)}:v=1:a=0[outv]'
    cmd=['ffmpeg','-y','-loglevel','error',*inputs]
    if a.music:
        if not a.music.is_file():p.error('Selected music is missing.')
        cmd += ['-stream_loop','-1','-i',str(a.music)]
    cmd += ['-filter_complex',filt,'-map','[outv]']
    if a.music:cmd += ['-map',f'{len(rendered)}:a:0','-c:a','aac','-b:a','160k','-shortest']
    cmd += ['-c:v','libx264','-pix_fmt','yuv420p','-movflags','+faststart',str(out)]
    subprocess.run(cmd,check=True)
    print(f'Assembled actual gameplay footage: {out} ({out.stat().st_size:,} bytes).')
