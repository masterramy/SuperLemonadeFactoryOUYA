param(
    [string]$Output = 'real_capture_01.mp4',
    [ValidateRange(5,180)][int]$Seconds = 45
)
# Record ONLY actual Android device output; no simulated gameplay.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$package='com.ramybaheeg.slfport'
function Find-Adb {
    $pathCmd=Get-Command 'adb.exe' -ErrorAction SilentlyContinue
    if($pathCmd) { return $pathCmd.Source }
    $candidates=@()
    foreach($root in @($env:ANDROID_SDK_ROOT,$env:ANDROID_HOME,(Join-Path $env:LOCALAPPDATA 'Android\Sdk'))) {
        if(-not [string]::IsNullOrWhiteSpace($root)) {
            $candidates += (Join-Path $root 'platform-tools\adb.exe')
        }
    }
    foreach($path in $candidates) { if(Test-Path -LiteralPath $path -PathType Leaf) {return $path} }
    throw 'adb not found in PATH or standard Android SDK locations. This is a capture prerequisite, not a game defect.'
}
$adb=Find-Adb
$devices=@(& $adb devices | Select-String '\sdevice$')
if($LASTEXITCODE -ne 0 -or $devices.Count -ne 1){throw 'Connect EXACTLY one authorized Android device with USB debugging enabled.'}
# Do not capture a different app, a locked phone, or accidentally include
# private notifications in a gameplay marketing video.
& $adb shell pidof $package | Out-Null
if($LASTEXITCODE -ne 0){throw "Package $package is not running. Open Super Limeade Factory on your device before recording."}
Write-Host "Capturing $Seconds seconds of REAL gameplay from $package."
Write-Host 'Close personal notifications/overlays first; record only gameplay you have permission to publish.'
$remote='/sdcard/slf_actual_gameplay_capture.mp4'
try {
    & $adb shell screenrecord --size 1920x1080 --bit-rate 8000000 --time-limit $Seconds $remote
    if($LASTEXITCODE -ne 0){throw 'Android screenrecord failed.'}
    & $adb pull $remote $Output
    if($LASTEXITCODE -ne 0){throw 'Could not retrieve screen recording.'}
    if(-not (Test-Path -LiteralPath $Output -PathType Leaf) -or (Get-Item -LiteralPath $Output).Length -lt 10000) {
        throw 'Recording is missing or implausibly small.'
    }
    $hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $Output).Hash.ToLowerInvariant()
    $summary=@(
        "source=real_android_screenrecord",
        "package=$package",
        "output=$Output",
        "seconds_requested=$Seconds",
        "sha256=$hash",
        "bytes=$((Get-Item -LiteralPath $Output).Length)"
    )
    $summary | Set-Content -LiteralPath ($Output+'.capture.txt') -Encoding UTF8
    Write-Host "REAL Android recording saved: $Output"
    Write-Host "Capture provenance receipt saved: $Output.capture.txt"
}
finally { & $adb shell rm -f $remote | Out-Null }
