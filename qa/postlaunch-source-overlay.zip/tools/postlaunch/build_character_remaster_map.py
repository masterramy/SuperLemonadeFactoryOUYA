#!/usr/bin/env python3
"""Build machine-checkable frame map for replacing the *actual* SLF character atlas.

This makes the original frame indexing explicit; reference illustrations must NOT
be substituted without meeting these geometry, alpha, and per-frame criteria.
"""
import json, re, hashlib
from pathlib import Path
from PIL import Image
ROOT = Path(__file__).resolve().parents[2]
sheet = ROOT / 'data/chars_50x50.png'
im=Image.open(sheet).convert('RGBA')
WIDTH,HEIGHT=50,80
assert im.size==(600,640), im.size
COLS,ROWS=im.width//WIDTH,im.height//HEIGHT
names=('PlayerMale','PlayerFemale','EnemyArmy','EnemyChef','EnemyInspector','EnemyWorker','EnemyGeneric')
entries={}; unique=set()
for name in names:
    p=ROOT/'src'/f'{name}.as'
    s=p.read_text(encoding='utf8')
    anims={}
    for anim,ids in re.findall(r'addAnimation\(\s*"([^\"]+)"\s*,\s*\[([^\]]+)\]',s):
        frames=[int(n) for n in re.findall(r'\d+',ids)]
        assert frames and all(0<=f<COLS*ROWS for f in frames),(name,anim,frames)
        anims[anim]=frames;unique.update(frames)
    assert anims,name
    entries[name]=anims
source_meta=[]
for i in sorted(unique):
    x=(i%COLS)*WIDTH;y=(i//COLS)*HEIGHT
    crop=im.crop((x,y,x+WIDTH,y+HEIGHT))
    source_meta.append({'frame':i,'x':x,'y':y,'width':WIDTH,'height':HEIGHT,'bbox_within_frame':crop.getchannel('A').getbbox()})
result={
    'status':'SOURCE_FRAME_MAP_ONLY_NOT_REMASTERED',
    'original_atlas':'data/chars_50x50.png',
    'original_sha256':hashlib.sha256(sheet.read_bytes()).hexdigest(),
    'sheet_size':[im.width,im.height], 'frame_size':[WIDTH,HEIGHT],
    'grid':[COLS,ROWS], 'referenced_frames':len(unique),
    'animations_by_game_class':entries,'referenced_frame_geometry':source_meta,
    'acceptance':['Exact 600x640 RGBA PNG','12 columns x 8 rows of 50x80',
                  'Frame semantic identity matches original animation index',
                  'Collision box and animation timings unchanged',
                  'Transparent slot margins and feet positions inspected',
                  'Both character directions and death/piggyback interactions verified in running Android game']
}
out=ROOT/'qa/postlaunch/CHARACTER_REMASTER_ANIMATION_MAP.json'
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print('PASS actual original atlas frame index map:',len(unique),'frames across',len(entries),'game classes ->',out)
