@echo off
rem Runs the cached AIR compiler in cmd.exe so PowerShell does not convert
rem individual compiler stderr lines into terminating NativeCommandError records.
setlocal
cd /d "%~dp0..\.."
if not defined SLF_POSTLAUNCH_COMPILER (
  echo ERROR: Missing SLF_POSTLAUNCH_COMPILER from the parent runner. 1>&2
  exit /b 90
)
if not defined SLF_POSTLAUNCH_SWF (
  echo ERROR: Missing SLF_POSTLAUNCH_SWF from the parent runner. 1>&2
  exit /b 91
)
call "%SLF_POSTLAUNCH_COMPILER%" "-load-config+=obj\SLF_for_OuyaConfig.xml" "-output=%SLF_POSTLAUNCH_SWF%"
exit /b %ERRORLEVEL%
