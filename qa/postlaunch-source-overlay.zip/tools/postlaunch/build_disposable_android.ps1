param([ValidateSet('phone','emulator')][string]$Target='phone')
# TEST-ONLY Android APK. Uses its OWN app ID and disposable test certificate.
# Must never touch the personal Play upload key or production-release scripts.
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$root=(Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location -LiteralPath $root
$toolchain=if($env:SLF_TOOLCHAIN_ROOT){$env:SLF_TOOLCHAIN_ROOT}else{Join-Path $env:LOCALAPPDATA 'SuperLemonadeFactory\toolchain'}
$air=if($env:AIR_HOME -and (Test-Path -LiteralPath (Join-Path $env:AIR_HOME 'bin\adt.bat'))){
    $env:AIR_HOME
}else{
    $adtOnPath=Get-Command 'adt.bat' -ErrorAction SilentlyContinue
    if($adtOnPath){Split-Path -Parent (Split-Path -Parent $adtOnPath.Source)}
    else{Join-Path $toolchain 'air-51.3.4.3'}
}
$adt=Join-Path $air 'bin\adt.bat'
if(-not(Test-Path -LiteralPath $adt)){throw "AIR ADT missing: $adt"}
# Use the exact JDK 17 installed by the local release kit or an isolated CI job.
# Never download JDKs, change machine-wide Java, or pick newer Java by accident.
$javaHomeCandidate=$null
if($env:JAVA_HOME -and (Test-Path -LiteralPath (Join-Path $env:JAVA_HOME 'bin\java.exe'))){
    $javaHomeCandidate=$env:JAVA_HOME
} else {
    $jdk=Get-ChildItem -LiteralPath (Join-Path $toolchain 'jdk17') -Recurse -Filter 'java.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if($jdk){$javaHomeCandidate=Split-Path -Parent (Split-Path -Parent $jdk.FullName)}
}
if(-not $javaHomeCandidate){throw 'Java 17 not found in JAVA_HOME or the local cached toolchain. Build will not install software.'}
$env:JAVA_HOME=$javaHomeCandidate
$env:PATH="$(Join-Path $env:JAVA_HOME 'bin');$env:PATH"
# Java prints version details to STDERR by design. Windows PowerShell 5.1
# turns stderr into NativeCommandError when ErrorActionPreference is Stop.
$oldPreference=$ErrorActionPreference
try {
    $ErrorActionPreference='Continue'
    $javaVersion=(& (Join-Path $env:JAVA_HOME 'bin\java.exe') '-version' 2>&1 | Out-String)
} finally {$ErrorActionPreference=$oldPreference}
if($LASTEXITCODE -ne 0 -or $javaVersion -notmatch 'version "17\.') {throw "Expected Java 17; actual: $javaVersion"}
$sdkCandidates=@($env:ANDROID_SDK_ROOT,$env:ANDROID_HOME,(Join-Path $toolchain 'android-sdk'),(Join-Path $env:LOCALAPPDATA 'Android\Sdk'))
$sdk=$null
foreach($candidate in $sdkCandidates){if(-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath (Join-Path $candidate 'platforms\android-36\android.jar'))) { $sdk=$candidate;break }}
if(-not $sdk){throw 'Android SDK platform 36 not found. No downloads attempted.'}
$srcSwf=Join-Path $root 'bin\SLFforOuya-postlaunch-wip.swf'
if(-not(Test-Path -LiteralPath $srcSwf)){throw 'First run COMPILE_POSTLAUNCH_WIP.bat successfully. Missing compiled SWF.'}
$outDir=Join-Path $root 'dist\postlaunch-disposable'
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$apkFile=if($Target -eq 'emulator'){'SLF-DEV-EMULATOR-x64.apk'}else{'SLF-DEV-PHONE.apk'}
$apk=Join-Path $outDir $apkFile
$swf=Join-Path $root 'bin\SLFforOuya.swf'
$devDescriptor=Join-Path $outDir 'application.dev.xml'
$key=Join-Path $outDir 'delete-after-packaging-disposable.p12'
$testPassword='slf-only-disposable-qa'
# Leave public release descriptor and uploaded source unchanged.
$descriptor=[IO.File]::ReadAllText((Join-Path $root 'application.xml'))
if(-not $descriptor.Contains('<id>com.ramybaheeg.slfport</id>')){throw 'Unexpected source package; refusing descriptor change.'}
$descriptor=$descriptor.Replace('<id>com.ramybaheeg.slfport</id>','<id>com.ramybaheeg.slfport.dev</id>')
$descriptor=$descriptor.Replace('<name>Super Limeade Factory</name>','<name>Super Limeade Factory DEV</name>')
[IO.File]::WriteAllText($devDescriptor,$descriptor,(New-Object System.Text.UTF8Encoding($false)))
$provider=Join-Path $air 'lib\android\lib\resources\app_entry\res\drawable-xhdpi\ouya_icon.png'
$providerBackup=Join-Path $env:TEMP ('slf-dev-provider-'+[Guid]::NewGuid().ToString('N')+'.png')
$sanitized=$false
$providerDigest='58d4af4a730200aacdb84a8c768d344b463428f6df9ecd4d7dca2e1cabf0e253'
try {
    Copy-Item -LiteralPath $srcSwf -Destination $swf -Force
    & $adt -certificate -validityPeriod 1 -cn 'SLF Disposable Development QA' 2048-RSA $key $testPassword
    if($LASTEXITCODE -ne 0 -or -not(Test-Path $key)){throw 'Could not create temporary test certificate.'}
    if(Test-Path -LiteralPath $provider){
        $actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $provider).Hash.ToLowerInvariant()
        if($actual -ne $providerDigest){throw 'Unknown AIR provider icon template; refusing to modify SDK files.'}
        Copy-Item -LiteralPath $provider -Destination $providerBackup -Force
        Remove-Item -LiteralPath $provider -Force
        $sanitized=$true
    }
    Remove-Item -LiteralPath $apk -Force -ErrorAction SilentlyContinue
    $targetArgs=if($Target -eq 'emulator'){@('-target','apk-emulator','-arch','x64')}else{@('-target','apk')}
    & $adt -package @targetArgs -storetype pkcs12 -keystore $key -storepass $testPassword $apk $devDescriptor `
        -C bin SLFforOuya.swf `
        -C icons/android icons/icon_48.png icons/icon_57.png icons/icon_72.png icons/icon_96.png icons/icon_114.png icons/icon_144.png icons/icon_192.png `
        -C . LICENSE THIRD_PARTY_NOTICES.md MODIFICATIONS.md SOURCE_DISCLOSURE.md -platformsdk $sdk
    if($LASTEXITCODE -ne 0 -or -not(Test-Path $apk)){throw 'Disposable APK packaging failed.'}
    $aapt=Join-Path $sdk 'build-tools\36.0.0\aapt.exe'
    if(-not(Test-Path $aapt)){throw 'Cannot verify package identity: Android aapt build tools 36 missing.'}
    $badging=(& $aapt dump badging $apk | Out-String)
    if($LASTEXITCODE -ne 0 -or $badging -notmatch "package: name='com\.ramybaheeg\.slfport\.dev'"){
        Remove-Item -LiteralPath $apk -Force -ErrorAction SilentlyContinue
        throw 'APK is not isolated under expected .dev package name; deleted for safety.'
    }
    if($badging -notmatch "versionCode='1009001'" -or $badging -notmatch "versionName='1\.9\.1'" -or
       $badging -notmatch "targetSdkVersion:'36'") {
        Remove-Item -LiteralPath $apk -Force -ErrorAction SilentlyContinue
        throw 'Disposable APK manifest/version identity unexpected; deleted for safety.'
    }
    $apkSignTool=Join-Path $sdk 'build-tools\36.0.0\apksigner.bat'
    if(-not (Test-Path -LiteralPath $apkSignTool)){throw 'Cannot verify QA APK certificate; apksigner unavailable.'}
    $sig=(& $apkSignTool verify --print-certs $apk 2>&1 | Out-String)
    if($LASTEXITCODE -ne 0){throw "Disposable APK signature invalid: $sig"}
    $certMatch=[regex]::Match($sig, '(?im)Signer #1 certificate SHA-256 digest:\s*([0-9a-fA-F]{64})')
    if(-not $certMatch.Success){throw 'Cannot identify APK signing certificate.'}
    $certSha=$certMatch.Groups[1].Value.ToLowerInvariant()
    if($certSha -eq '73c5debce610e0655e5edd1ce8046100184a5c63c8fdb308d12ec1a0d50ed248'){
        Remove-Item -LiteralPath $apk -Force -ErrorAction SilentlyContinue
        throw 'Refusing disposable build signed by Production upload certificate.'
    }
    $permissions=(& $aapt dump permissions $apk 2>&1 | Out-String)
    if($LASTEXITCODE -ne 0 -or $permissions -match '(?im)^\s*uses-permission(?:-sdk-\d+)?:'){
        Remove-Item -LiteralPath $apk -Force -ErrorAction SilentlyContinue
        throw 'Unexpected Android permission in disposable QA APK.'
    }
    $sha=(Get-FileHash -Algorithm SHA256 -LiteralPath $apk).Hash.ToLowerInvariant()
    @("status=QA_BUILD_PASS_NOT_PRODUCTION", "package=com.ramybaheeg.slfport.dev", "purpose=independent_test_only", "target=$Target", "aab_created=false", "prod_signing_key_touched=false", "bytes=$((Get-Item $apk).Length)", "sha256=$sha", "test_signer_sha256=$certSha", "permissions=none") |
        Set-Content -LiteralPath (Join-Path $outDir 'SLF_DISPOSABLE_APK_RECEIPT.txt') -Encoding utf8
    Write-Host "Built ISOLATED development APK: $apk" -ForegroundColor Green
    Write-Host 'This uses a disposable signing certificate and cannot update the Google Play app.'
}
finally {
    if(Test-Path $key){Remove-Item -LiteralPath $key -Force}
    if($sanitized){Copy-Item -LiteralPath $providerBackup -Destination $provider -Force}
    Remove-Item -LiteralPath $providerBackup -Force -ErrorAction SilentlyContinue
}
