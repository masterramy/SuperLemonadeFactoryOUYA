#!/usr/bin/env python3
"""Enumerate all actual embedded PNGs, and identify sprite sheet geometry for a remaster."""
from pathlib import Path
from PIL import Image
import csv,re
root=Path(__file__).resolve().parents[2]
rows=[]
for path in (root/'src').rglob('*.as'):
    text=path.read_text(encoding='utf-8-sig',errors='replace')
    for m in re.finditer(r'\[Embed\(source\s*=\s*[\'\"]([^\'\"]+\.png)[\'\"]\)\]',text,re.I):
        asset=(path.parent/m.group(1)).resolve()
        if not asset.exists(): continue
        with Image.open(asset) as img:
            rows.append({'source':str(path.relative_to(root)),'asset':str(asset.relative_to(root)), 'width':img.width,'height':img.height,'mode':img.mode,'sha256':__import__('hashlib').sha256(asset.read_bytes()).hexdigest()})
rows.sort(key=lambda x:(x['asset'],x['source']))
out=root/'qa/postlaunch/ACTUAL_GAME_GRAPHICS_ASSET_INVENTORY.csv'
out.parent.mkdir(parents=True,exist_ok=True)
with out.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=['source','asset','width','height','mode','sha256']);w.writeheader();w.writerows(rows)
print(f'{len(rows)} embeds, {len(set(x["asset"] for x in rows))} unique files -> {out}')
