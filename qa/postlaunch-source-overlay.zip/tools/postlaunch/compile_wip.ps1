# Compile-only post-launch worktree. No Android package, signing, network upload, or Play mutation.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
Set-Location -LiteralPath $root

function Find-AirCompiler {
  $fromPath = Get-Command 'amxmlc.bat' -ErrorAction SilentlyContinue
  if ($fromPath) { return $fromPath.Source }
  if ($env:AIR_HOME) {
    $found = Join-Path $env:AIR_HOME 'bin\amxmlc.bat'
    if (Test-Path -LiteralPath $found) { return $found }
  }
  $toolchain = if ($env:SLF_TOOLCHAIN_ROOT) { $env:SLF_TOOLCHAIN_ROOT } else {
    Join-Path $env:LOCALAPPDATA 'SuperLemonadeFactory\toolchain'
  }
  $fixed = Join-Path $toolchain 'air-51.3.4.3\bin\amxmlc.bat'
  if (Test-Path -LiteralPath $fixed) { return $fixed }
  # Use an already-installed AIR version if exact prior cache directory moved.
  $candidates = @(Get-ChildItem -LiteralPath $toolchain -Directory -Filter 'air-*' -ErrorAction SilentlyContinue |
      Sort-Object Name -Descending | ForEach-Object { Join-Path $_.FullName 'bin\amxmlc.bat' } | Where-Object { Test-Path -LiteralPath $_ })
  if ($candidates.Count -gt 0) { return $candidates[0] }
  throw 'Adobe AIR amxmlc not found. The previous signing-kit toolchain should be installed under LocalAppData\SuperLemonadeFactory\toolchain. Send this log back instead of reinstalling or signing anything.'
}
function Prepare-Java {
  if ($env:JAVA_HOME -and (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    $env:PATH = "$(Join-Path $env:JAVA_HOME 'bin');$env:PATH"
    return
  }
  $toolchain = if ($env:SLF_TOOLCHAIN_ROOT) { $env:SLF_TOOLCHAIN_ROOT } else {
    Join-Path $env:LOCALAPPDATA 'SuperLemonadeFactory\toolchain'
  }
  $jdk = Join-Path $toolchain 'jdk17'
  $candidate = Get-ChildItem -LiteralPath $jdk -Filter 'java.exe' -Recurse -File -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($candidate) {
    $env:JAVA_HOME = Split-Path -Parent (Split-Path -Parent $candidate.FullName)
    $env:PATH = "$(Join-Path $env:JAVA_HOME 'bin');$env:PATH"
  }
}
Write-Host 'SUPER LIMEADE FACTORY — POST-LAUNCH DEVELOPMENT COMPILE' -ForegroundColor Cyan
Write-Host 'NO signing, AAB, Play upload, public release or keystore access.'
Write-Host 'Source:' $root
Prepare-Java
$amxmlc = Find-AirCompiler
Write-Host 'AIR compiler:' $amxmlc
$java = Get-Command 'java.exe' -ErrorAction SilentlyContinue
if (-not $java) { throw 'Java not found. Send this output to Limeade Alfred; do not modify the Production toolchain.' }
Write-Host 'Java:' $java.Source
New-Item -ItemType Directory -Force -Path (Join-Path $root 'bin') | Out-Null
$output = Join-Path $root 'bin\SLFforOuya-postlaunch-wip.swf'
# A .cmd shim captures native STDOUT and STDERR to separate raw text files.
# PowerShell 5.1 with ErrorActionPreference=Stop otherwise truncates the first
# native compiler diagnostic into an unhelpful NativeCommandError.
$shim = Join-Path $PSScriptRoot 'invoke_air_compiler.cmd'
if (-not (Test-Path -LiteralPath $shim -PathType Leaf)) { throw "Missing compiler shim: $shim" }
$env:SLF_POSTLAUNCH_COMPILER = $amxmlc
$env:SLF_POSTLAUNCH_SWF = $output
$rawOut = Join-Path $root 'POSTLAUNCH_AIR_STDOUT.txt'
$rawErr = Join-Path $root 'POSTLAUNCH_AIR_STDERR.txt'
Remove-Item -LiteralPath $rawOut,$rawErr -Force -ErrorAction SilentlyContinue
Write-Host 'Native compiler logs:' $rawOut 'and' $rawErr
# cmd.exe /d /s /c ""PATH TO SHIM"" handles spaces and parentheses in user paths.
$cmdLine = '/d /s /c ""' + $shim + '""'
$run = Start-Process -FilePath $env:ComSpec -ArgumentList $cmdLine `
    -WorkingDirectory $root -Wait -PassThru -NoNewWindow `
    -RedirectStandardOutput $rawOut -RedirectStandardError $rawErr
$rc = $run.ExitCode
Write-Host '--- BEGIN COMPILER STDOUT ---'
if (Test-Path -LiteralPath $rawOut) { Get-Content -LiteralPath $rawOut | ForEach-Object { Write-Host $_ } }
Write-Host '--- END COMPILER STDOUT ---'
Write-Host '--- BEGIN COMPILER STDERR ---'
if (Test-Path -LiteralPath $rawErr) { Get-Content -LiteralPath $rawErr | ForEach-Object { Write-Host $_ } }
Write-Host '--- END COMPILER STDERR ---'
Write-Host "AIR_COMPILER_EXIT_CODE=$rc"
if ($rc -ne 0) { throw "AIR compiler failed with exit code $rc; attach POSTLAUNCH_COMPILE_RESULT.txt (raw native logs also saved)." }
if (-not (Test-Path -LiteralPath $output)) { throw 'Compiler exited without creating an SWF.' }
$hash=(Get-FileHash -Algorithm SHA256 -LiteralPath $output).Hash.ToLowerInvariant()
Write-Host 'COMPILATION PASSED. DEVELOPMENT SWF ONLY.' -ForegroundColor Green
Write-Host "SWF_SHA256=$hash"
Write-Host "SWF_BYTES=$((Get-Item $output).Length)"
