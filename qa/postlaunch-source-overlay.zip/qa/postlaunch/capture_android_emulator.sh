#!/usr/bin/env bash
# Real Android emulator output only: no replacement art, frame synthesis,
# gameplay teleports, modified level maps, or pre-recorded scene injections.
# All captures remain QA evidence until visually inspected.
set -euo pipefail
APK="${1:?Provide independently built x86_64 development APK}"
OUT="${2:-qa/postlaunch-real-emulator}"
PKG='com.ramybaheeg.slfport.dev'
mkdir -p "$OUT"
[[ -f "$APK" ]] || { echo "APK missing: $APK" >&2; exit 1; }
adb install -r "$APK" | tee "$OUT/install.txt"
adb shell pm clear "$PKG"
adb shell wm size 1920x1080
adb shell wm density 420
adb shell settings put secure immersive_mode_confirmations confirmed || true
adb shell am start -W -n "$PKG/.AIRAppEntry" | tee "$OUT/launch.txt"
sleep 9
adb exec-out screencap -p > "$OUT/01_title.png"
# Genuine Android touches through game title and menu, never a QA-only level jump.
adb shell input tap 960 850
sleep 5
adb exec-out screencap -p > "$OUT/02_menu_or_transition.png"
adb shell input tap 480 900
sleep 5
adb exec-out screencap -p > "$OUT/03_level_select_or_menu.png"
# Original Level 1 is the leftmost button at internal (140,120) on 640x360.
adb shell input tap 560 390
sleep 5
adb exec-out screencap -p > "$OUT/04_level1_or_intro.png"
# Attempt ordinary screen/button actions, do not edit save state or game source.
for _ in 1 2 3 4; do adb shell input tap 1780 930; sleep 1; done
adb exec-out screencap -p > "$OUT/05_after_story_actions.png"
# Capture the actual Android screen; not a fabricated gameplay reconstruction.
adb shell screenrecord --size 1920x1080 --bit-rate 6500000 --time-limit 24 '/sdcard/slf_real_qa.mp4' &
RECORD_PID=$!
sleep 3
for _ in 1 2 3 4 5 6; do
  adb shell input swipe 280 890 540 890 650
  adb shell input tap 1780 930
  sleep 1
  adb shell input tap 1650 930
  sleep 1
done
wait "$RECORD_PID"
adb pull /sdcard/slf_real_qa.mp4 "$OUT/actual_android_recording.mp4"
adb shell rm /sdcard/slf_real_qa.mp4 || true
adb logcat -d > "$OUT/logcat.txt" || true
ffprobe -v error -select_streams v:0 -show_entries stream=width,height,codec_name -of default=noprint_wrappers=1 "$OUT/actual_android_recording.mp4" | tee "$OUT/video_metadata.txt"
sha256sum "$APK" "$OUT/actual_android_recording.mp4" > "$OUT/provenance.sha256"
printf 'capture_method=real_android_emulator_screenrecord\napp_package=%s\noriginal_gameplay_code_unchanged=yes\nreview_state=QA_NOT_ADVERTISING_APPROVED\n' "$PKG" > "$OUT/provenance.txt"
echo "Captured genuine emulator screen video for inspection: $OUT"
