# Art direction exploration — NOT an integration asset

The concept atlas stored here is a generated visual reference only. Its visual
character style suggests a genuinely redrawn pixel-art remaster. It is **not**
compatible with the original 600×640 PNG / 50×80 frame-slot layout and does NOT
use the original game's frame order. Do not copy or resize it into game sources.

Before accepting an actual remastered character atlas, satisfy
`CHARACTER_REMASTER_ANIMATION_MAP.json`: precisely matched frame identities,
feet position, alpha margins, gameplay-facing outlines, idle/run/death/talk,
piggyback/dash and every other source animation. Then visually test physical
Android runtime. Current Classic graphics have not been replaced.
