@echo off
setlocal
cd /d "%~dp0"
echo SUPER LIMEADE FACTORY - ISOLATED DEVICE TEST APK
 echo This CANNOT replace, sign, or upload the production game.
set "LOG=POSTLAUNCH_TEST_APK_RESULT.txt"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\postlaunch\build_disposable_android.ps1" -Target phone > "%LOG%" 2>&1
set "RESULT=%ERRORLEVEL%"
type "%LOG%"
echo.
echo EXIT_CODE=%RESULT%
echo Nonsecret test log saved to %LOG%
pause
exit /b %RESULT%
