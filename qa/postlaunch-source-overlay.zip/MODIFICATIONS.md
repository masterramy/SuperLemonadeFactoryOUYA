# Modification Notice — Super Limeade Factory

Super Limeade Factory is a modified Android edition of the GPLv3-released OUYA source of **Super Lemonade Factory**.

## Who changed it

Android restoration, modernization, release-hardening, branding, and packaging changes were made in **2026** by **Ramy Baheeg**.

## Relationship to the original game

- Original game: **Super Lemonade Factory**
- Original developer: **Shane Brouwer / Initials Video Games**
- This Android edition: **Super Limeade Factory**
- Publisher of this Android edition: **Ramy Baheeg**
- Status: independent restoration/modification
- Affiliation: **not produced, sponsored, or endorsed by Shane Brouwer or Initials Video Games**

No response or silence from the original developer is represented as approval or endorsement.

## Material modification areas

The modified edition includes, among other release-history changes:

- current HARMAN AIR / Android packaging and API-level modernization;
- modern Android input, lifecycle, display, foldable, and touch-control compatibility work;
- adaptive touch-control placement and persistent control-height preference;
- corrected customer-facing control instructions and repaired Android runtime behavior;
- privacy, source-disclosure, license, and third-party notice surfaces;
- Super Limeade Factory naming and lime-green visual treatment for the independent Android edition;
- release verification, manifest inspection, source provenance, and fail-closed production-signing tooling.

Repository history is the authoritative detailed record of file-level changes.

## License

The covered work is distributed under **GNU GPL version 3**. See `LICENSE`.

Third-party components retain their own notices and license grants as documented in `THIRD_PARTY_NOTICES.md` and `third_party/licenses/`.

## Corresponding source

Public source repository:

https://github.com/masterramy/SuperLemonadeFactoryOUYA

For a distributed release, the release dossier identifies the exact Git commit/tree and source archive corresponding to the binary.


## Android v1.9.1 title-screen presentation update (2026-10-16)

Replaces the illustrated intro and menu presentation with approved native-resolution pixel-art factory backgrounds (data/branding/title_intro_640.png and title_menu_640.png). Retains original input handlers, menu selection, state transitions, controller routing, gameplay maps, player physics, puzzles, audio and save behavior. Adds the title-screen image embeds in Registry.as and relocates the real menu buttons onto a branded menu strip. The version increments to v1.9.1 (code 1009001). Corresponding source includes these exact title assets, modified AS3 files and build tools.

## Isolated post-launch development (not distributed)

- Android GameInput recognizes left-stick and HAT-axis D-pad inputs.
- Provider-independent cloud-save parser validates exact snapshot field set and integer schema prior to monotonic merge; no Play Games SDK or network access included.
- Prioritized exact source-used graphic inventory (`qa/postlaunch/REMASTER_ASSET_PRIORITY.csv`) and frame-sheet constraints.
- ADB gameplay recording script preflights the game process and emits source SHA-256 receipt.
- Separate Android DEV APK builder (`.dev` package name and disposable testing certificate) prepared; not executed on Windows or Google Play.

## October 17 post-launch continuation (development only)

- Developer-only Options diagnostic uses the Android `.dev` application ID gate; never displayed in submitted Play package. Shows discovered controller name (bounded), Android/legacy mapping and A/B/left/right/up/down pressed status. No persistent hardware identifiers, account data or network transfer.
- `qa/postlaunch/CHARACTER_REMASTER_ANIMATION_MAP.json` now enumerates the **real** 600×640 source sheet, 50×80 frames, 69 animation-used frames across 7 game classes. A generated image concept is *not* a drop-in sprite sheet; original collision, animation and frame index meanings remain authoritative.
- Google Play Games cloud sync remains blocked on actual Google Play Games app configuration and a compatible native extension. Never advertise it based on the existing local codec.
- Trailer remains the independently verified silent original-game three-world QA draft; requires final owner marketing signoff and sound rights.
