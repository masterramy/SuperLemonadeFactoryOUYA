@echo off
setlocal
cd /d "%~dp0"
set "REPORT=%~dp0POSTLAUNCH_COMPILE_RESULT.txt"
echo Super Limeade Factory -- POST-LAUNCH DEVELOPMENT ONLY
echo This will NOT sign, package, upload, or publish the game.
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\postlaunch\compile_wip.ps1" > "%REPORT%" 2>&1
set "RC=%ERRORLEVEL%"
type "%REPORT%"
echo.
echo =====================================================
if "%RC%"=="0" (
  echo COMPILE PASSED. Send POSTLAUNCH_COMPILE_RESULT.txt to Limeade Alfred.
) else (
  echo COMPILE NEEDS ATTENTION. Send POSTLAUNCH_COMPILE_RESULT.txt to Limeade Alfred.
)
echo This package cannot publish or change your current Play release.
echo =====================================================
pause
exit /b %RC%
