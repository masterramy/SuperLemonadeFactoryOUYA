// Copyright 2026 independent Super Limeade Factory Android restoration.
// Prototype mode: only three decorative 10px tile strips have alternate artwork.
package
{
    import org.flixel.FlxSave;
    public class GraphicsMode
    {
        private static const SAVE_KEY:String = "graphicsMode";
        public static var remastered:Boolean = false;
        public static function load():void
        {
            var save:FlxSave = new FlxSave();
            if (save.bind("SLF"))
            {
                remastered = (save.data.graphicsMode == "remastered");
                save.close();
            }
            else remastered = false;
        }
        public static function toggle():Boolean
        {
            var save:FlxSave = new FlxSave();
            if (!save.bind("SLF")) return false;
            var newMode:Boolean = !remastered;
            save.data.graphicsMode = newMode ? "remastered" : "classic";
            if (!save.close()) return false;
            remastered = newMode;
            return true;
        }
        public static function choose(classicArt:Class, enhancedArt:Class):Class
        {
            return (remastered && enhancedArt != null) ? enhancedArt : classicArt;
        }
    }
}
