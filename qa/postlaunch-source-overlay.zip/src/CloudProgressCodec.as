// Copyright 2026 Super Limeade Factory Android restoration.
// A provider-independent, progression-only cloud save codec. No network access
// here: do NOT describe this as activated Play Games synchronization.
package
{
    import org.flixel.FlxSave;
    public class CloudProgressCodec
    {
        public static const SCHEMA:int = 1;
        private static const FIELDS:Array = [
            "warehouseLevelsComplete", "factoryLevelsComplete", "mgmtLevelsComplete",
            "hcwarehouseLevelsComplete", "hcfactoryLevelsComplete", "hcmgmtLevelsComplete",
            "warehouseLevelsTalk", "factoryLevelsTalk", "mgmtLevelsTalk",
            "hcwarehouseLevelsTalk", "hcfactoryLevelsTalk", "hcmgmtLevelsTalk",
            "warehouseLevelsTalkAndre", "factoryLevelsTalkAndre", "mgmtLevelsTalkAndre",
            "hcwarehouseLevelsTalkAndre", "hcfactoryLevelsTalkAndre", "hcmgmtLevelsTalkAndre",
            "warehouseCap", "factoryCap", "mgmtCap",
            "hcwarehouseCap", "hcfactoryCap", "hcmgmtCap"
        ];

        // Must remain exactly aligned with FIELDS and Registry.normaliseProgressSave.
        // Validating labels prevents mismatched categories in imported cloud data.
        private static const LABELS:Array = [
            "wh   ",
            "fc   ",
            "mgmt ",
            "xwh  ",
            "xfc  ",
            "xmgmt",
            "wh-talk   ",
            "fc-talk   ",
            "mgmt-talk ",
            "xwh-talk  ",
            "xfc-talk  ",
            "xmgmt-talk",
            "wh-talk-andre   ",
            "fc-talk-andre   ",
            "mgmt-talk-andre ",
            "xwh-talk-andre  ",
            "xfc-talk-andre  ",
            "xmgmt-talk-andre",
            "whcap   ",
            "fccap   ",
            "mgmtcap ",
            "xwhcap  ",
            "xfccap  ",
            "xmgmtcap"
        ];

        public static function capture():String
        {
            var save:FlxSave = new FlxSave();
            if (!save.bind("SLF")) return null;
            Registry.normaliseProgressSave(save);
            var result:Object = { schema: SCHEMA, arrays: {} };
            for each (var field:String in FIELDS)
                result.arrays[field] = (save.data[field] as Array).concat();
            save.close();
            return JSON.stringify(result);
        }

        // Validate the exact snapshot field set before any merge or local write.
        // An unexpected field likely indicates a schema mismatch or malformed
        // snapshot and must not be silently dropped during synchronization.
        private static function validFieldSet(data:Object):Boolean
        {
            if (data == null || data.arrays == null || data.arrays is Array) return false;
            // This schema has exactly two envelope keys; reject unknown versions
            // and metadata before writing anything to the device save.
            var envelopeKeys:int = 0;
            for (var envelope:String in data)
            {
                if (envelope != "schema" && envelope != "arrays") return false;
                envelopeKeys++;
            }
            if (envelopeKeys != 2) return false;
            var seen:int = 0;
            for (var key:String in data.arrays)
            {
                if (FIELDS.indexOf(key) < 0) return false;
                seen++;
            }
            return seen == FIELDS.length;
        }

        // Merge two trusted-by-schema snapshots, monotonically retaining all
        // observed achievements. Malformed remote input rejects the entire sync.
        // 0 -> 1 never regresses; label/array geometry comes from local progress.
        public static function merge(localJSON:String, remoteJSON:String):String
        {
            if (localJSON == null || remoteJSON == null ||
                localJSON.length > 65536 || remoteJSON.length > 65536)
                return null;
            var local:Object, remote:Object;
            try { local = JSON.parse(localJSON); remote = JSON.parse(remoteJSON); }
            catch (error:Error) { return null; }
            if (local == null || remote == null || local.schema !== SCHEMA || remote.schema !== SCHEMA ||
                !validFieldSet(local) || !validFieldSet(remote)) return null;
            var merged:Object = { schema: SCHEMA, arrays: {} };
            for (var f:int = 0; f < FIELDS.length; f++)
            {
                var field:String = FIELDS[f];
                var label:String = LABELS[f];
                var l:Array = local.arrays[field] as Array;
                var r:Array = remote.arrays[field] as Array;
                if (l == null || r == null || l.length != 13 || r.length != 13 ||
                    l[0] !== label || r[0] !== label)
                    return null;
                var result:Array = [label];
                for (var i:int = 1; i < 13; i++)
                {
                    // Never coerce numbers/bools to strings: malformed snapshots
                    // must not gain progress or corrupt the local save.
                    if (!(l[i] is String) || !(r[i] is String)) return null;
                    var lv:String = l[i] as String;
                    var rv:String = r[i] as String;
                    if ((lv != "0" && lv != "1") || (rv != "0" && rv != "1")) return null;
                    result[i] = (lv == "1" || rv == "1") ? "1" : "0";
                }
                merged.arrays[field] = result;
            }
            return JSON.stringify(merged);
        }

        // Only called AFTER the service has authenticated and downloaded a
        // verified snapshot. Always merge with fresh local state before writing.
        public static function mergeIntoLocal(remoteJSON:String):Boolean
        {
            var localJSON:String = capture();
            var mergedJSON:String = merge(localJSON, remoteJSON);
            if (mergedJSON == null) return false;
            var parsed:Object = JSON.parse(mergedJSON);
            var save:FlxSave = new FlxSave();
            if (!save.bind("SLF")) return false;
            for each (var field:String in FIELDS)
                save.data[field] = (parsed.arrays[field] as Array).concat();
            Registry.normaliseProgressSave(save);
            return save.close();
        }
    }
}
