# Super Limeade Factory — post-launch feature track (UNRELEASED)

**Current paid app:** Super Limeade Factory v1.9.1, Android `com.ramybaheeg.slfport`, version code `1009001`. Submitted by owner to Google Play **Production review** October 16, 2026. Approval/public listing unverified. This working tree is an isolated fork of the full owner-approved corresponding source. **Do not use the supplied old production/signing scripts for this modified tree**: their exact source integrity guards intentionally target the previously verified release. Do not update the app or its matching public GPL source until the new game package is independently verified and the owner approves publication. No production secrets are included.

## What is implemented (predecessor compile PASS, newest changes need compiling)

- **Game controllers, Android:** Added `GameInput` polling + hotplug support in `src/org/flixel/system/input/FlxJoystick.as`; the `FlxG` input loop now polls each frame. Recognizes common Xbox/PlayStation/Bluetooth gamepad names; handles face buttons, Start/Back and directional movement with stick dead zone and just-pressed edges. Original game mechanics, keyboard and touch input remain intact. **Needs a real AIR compile plus Xbox/PlayStation test on Android before asserting compatibility.** The Options controller button index bug discovered during postlaunch review has been corrected: index0=delete, index1=graphics mode, index2=back. Unknown control maps deliberately do not activate.
- **Cloud-save data layer:** `src/CloudProgressCodec.as` exports and merges *only* the existing 24 local progress arrays, preserving the most progressed flags from both devices and rejecting malformed snapshots. No new user account or data transmission is implemented. This is **not cloud backup yet**. Before connecting Google Play Games Saved Games, obtain a working PGS v2-compatible Adobe AIR native extension, Google Play Games app ID and authorization, opt-in/sign-in flow, conflict resolution, non-destructive restore, offline retry policy and privacy/Play disclosure updates. The current offline/no-permissions game remains unchanged.
- **Graphics mode architecture, PROTOTYPE ONLY:** `GraphicsMode.as`, menu toggle in `PCOptionsState.as`, and visual class selection in `PlayState.as`. Three 180×10 factory-world decorative tile-strip candidates are produced at matching pixel geometry and alpha transparency. The option reads `Remastered (preview)` because **the actual gameplay characters, backgrounds, animations and most sprites are NOT remastered**. Absolutely do not ship or advertise full 'Remastered' mode yet. A true complete, art-consistent remaster requires replacing/upgrading the 76 unique source-embedded PNGs and other dynamically loaded art without affecting tile boundaries, collisions, spritesheet frames, gameplay or original Classic mode.
- **Trailer production tools:** `tools/postlaunch/capture_real_gameplay.ps1` uses `adb screenrecord` on a real Android handset; `tools/postlaunch/make_trailer_from_real_video.py` builds an accurately represented 16:9 sequence from genuine clips with optional authorized music. No gameplay footage was recorded or produced in this chat. **Do not advertise an AI-generated or still-image slideshow as a gameplay trailer.**

## Compile/test checklist

1. Extract entire archive in a new folder (do **not** overwrite v1.9.1 Production files).
2. Run `COMPILE_POSTLAUNCH_WIP.bat` on Windows. It now automatically discovers the owner-local AIR SDK/Java 17 installed by the v1.9.1 signer and writes `POSTLAUNCH_COMPILE_RESULT.txt` for sharing. It always pauses when finished, including on an error. Do not reinstall toolchains unless the log confirms none is available. It compiles an SWF ONLY; NO Android package or signing occurs.
3. For a disposable Android QA build after a clean source commit, adapt the existing emulator APK builder from this development tree. Sign with *disposable* testing certificate only; never use the production upload certificate here.
4. On a real Android phone, connect Xbox/PlayStation controllers, test Android GameInput IDs, each action, Start/pause and navigation, disconnection/reconnection, and touch coexistence. Modify mappings based on observed **nonsecret** controller control IDs, not assumptions.
5. For cloud saves, configure PGSv2 and verify a licensed native extension before integrating into the compile or modifying the production Android manifest. Test account A / two devices / offline conflicts / invalid snapshots. No silent data loss.
6. Review sample graphics on the emulator; regenerate comprehensive authentic replacement art before allowing Remastered mode in a release.
7. Record actual game movement/puzzles using the two included trailer scripts; assemble and visually review the footage. Choose soundtrack only if redistribution in marketing is allowed.
8. Only after hardware/platform/runtime PASS, prepare a **new** versionCode, exact complete GPL corresponding source ZIP, owner-local signing workflow, and owner-approved Play update.

## Source and compliance

This development bundle includes original source and artwork under existing repository notices. Keep `LICENSE`, `MODIFICATIONS.md`, `THIRD_PARTY_NOTICES.md` and `SOURCE_DISCLOSURE.md`. Any publicly distributed binary built from this modified source requires a matching source distribution. The current Play v1.9.1 release and `android-v1.9.1-source` tag are not overwritten.

## Verified so far

- `qa/postlaunch/validate_postlaunch.py`: source/schema/static/geometry checks, **not** ActionScript compilation.
- `qa/postlaunch/ACTUAL_GAME_GRAPHICS_ASSET_INVENTORY.csv`: 145 Embed PNG references covering 76 unique existing files, not a count of every standalone source asset.
- New small decorative tiles preserve original dimensions and **byte-exact alpha**.

## Actual external dependencies

- Current Google Play Games v2 Saved Games configuration in Play Console, official https://developer.android.com/games/pgs/savedgames.
- AIR PGSv2 integration candidate: https://docs.airnativeextensions.com/docs/gameservices/service/playgames/add-the-extension/ (potential separate license; not included or purchased).
- Actual owner-controlled Xbox/PlayStation Bluetooth controllers and Android device for runtime QA.
- Real game recording for trailer. Until captured, the trailer is **not finished**.


## October 16 compile-log repair (not a build PASS)

The previous PowerShell runner surfaced only `obj/SLF_for_OuyaConfig.xml:4` and stopped at `NativeCommandError`, losing the actual AIR stderr diagnostic. The XML matches the one used by the existing release builder; its contents have **not** been changed speculatively. This package now executes the same `amxmlc` invocation through a `cmd.exe` shim, captures the *entire* native stdout/stderr into `POSTLAUNCH_AIR_STDOUT.txt` and `POSTLAUNCH_AIR_STDERR.txt`, reports the actual exit code, and copies those messages into `POSTLAUNCH_COMPILE_RESULT.txt`.

Double-click `COMPILE_POSTLAUNCH_WIP.bat`. Send the result TXT after it finishes. If compilation fails, the raw two TXT logs can help too. This is **development SWF compilation only**; it cannot sign, upload, publish or alter the Production v1.9.1 release.

## Continued work after successful Windows compile receipt

The owner compiled the *previous* worktree on October 16 using AIR 51.3.4.3 and JDK17: exit code 0, 12,462,218-byte SWF SHA256 `826a505c6d7d027d81a8c17400f22e7e3bfd1370829b788186cdcab4572eb70e`. Two XML warnings were nonfatal. This does **NOT** compile-verify newer source additions.

The newer source adds Android GameInput D-pad HAT axis support; strict cloud snapshot field/schema validation; a source-indexed remaster art inventory; reliable ADB package/process recording with capture hash; and `BUILD_DISPOSABLE_TEST_APK.bat` with a separate `com.ramybaheeg.slfport.dev` app ID and one-day disposable signing certificate. The new APK builder has NOT been tested on Windows.

See `tools/postlaunch/POSTLAUNCH_NEXT_STEPS.md` for exact release boundaries.

## Fold Bluetooth controller acceptance — newer disposable DEV build

Install only the verified `com.ramybaheeg.slfport.dev` APK from the GitHub QA build.
Its disposable test signature is not stable between CI jobs. If you already have
an older `.dev` APK installed, uninstall **only Super Limeade Factory DEV**
first; never uninstall the Google Play `com.ramybaheeg.slfport` app or delete
its data. DEV progress is disposable.

Pair an Xbox/PlayStation/compatible Bluetooth gamepad with the phone, then:

1. Start **Super Limeade Factory DEV** and open Options.
2. At the bottom, the **developer-only** status panel should show the controller
   name, recognized Android/legacy layout, held A/B and four direction states.
3. Press and hold A, then each direction, and capture screenshots if any fields
   fail to change. Use gamepad navigation to return to the menu and play a level.
4. In the level verify walking, jumping, actions, switching, pause and Bluetooth
   disconnect/reconnect. Confirm touch still works after disconnect.

The on-screen panel reports only a bounded device-name string and live input
state. It never sends or stores personal data; it does not appear in production.
If no controller appears, report exact displayed text and gamepad model.

**Important:** Successful static QA, Windows AIR compilation, or emulator tests
cannot replace an actual Bluetooth controller/physical device PASS. No new AAB
or Store changes are authorized by these developer APKs.
