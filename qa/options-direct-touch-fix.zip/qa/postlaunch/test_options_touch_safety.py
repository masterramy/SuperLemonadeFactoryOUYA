from pathlib import Path
root=Path(__file__).resolve().parents[2]
o=(root/'src/PCOptionsState.as').read_text()
m=(root/'src/MobileControls.as').read_text()
assert o.count('public function activateOptionsButtonAt')==1
assert 'var choices:Array = [eraseBtn, graphicsBtn, backBtn]' in o
assert 'if (index == 0) deleteHistory()' in o
assert 'else if (index == 1) changeGraphics()' in o
assert 'else onQuit()' in o
assert 'return false;' in o.split('public function activateOptionsButtonAt',1)[1].split('private function changeGraphics',1)[0]
route=m.split('else if (FlxG.state is PCOptionsState)',1)[1].split('else pulseKey(KEY_X);',1)[0]
assert 'activateOptionsButtonAt(optX, optY)' in route
assert 'pulseKey(KEY_X)' not in route
assert 'activateMenuButtonAt(gameX, gameY)' in m
print('PASS Options button touch hit tests and no blank-tap Delete; menu route preserved')
