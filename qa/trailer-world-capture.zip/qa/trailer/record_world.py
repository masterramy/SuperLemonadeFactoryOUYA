#!/usr/bin/env python3
"""Capture authentic ordinary inputs on an original QA-isolated stage.
QA-only entrypoint; original game physics, maps, sprite art and player behavior.
"""
import os, subprocess, time, re, hashlib
from pathlib import Path
out=Path('real-world-video')/os.environ['WORLD']
out.mkdir(parents=True,exist_ok=True)
apk=Path('qa-apk/dist/emulator-qa/SLF-emulator-x64.apk')
pkg='com.ramybaheeg.slfport'
key={'LEFT':105,'RIGHT':106,'C':46,'X':45,'V':47}
def run(args,check=True,timeout=80):
    p=subprocess.run(args,text=True,capture_output=True,timeout=timeout)
    if check and p.returncode:raise RuntimeError(f'{args}: {p.returncode}, {p.stdout}, {p.stderr}')
    return p.stdout
def shell(command,check=True):return run(['adb','shell',command],check=check)
def frame(name):
    p=subprocess.run(['adb','exec-out','screencap','-p'],capture_output=True,timeout=25)
    if p.returncode==0 and p.stdout:(out/name).write_bytes(p.stdout)
assert hashlib.sha256(apk.read_bytes()).hexdigest()==os.environ['EXPECTED_SHA'],'Wrong source APK!'
run(['adb','root'],check=False);time.sleep(2)
run(['adb','wait-for-device'])
run(['adb','install','-r',str(apk)])
shell('pm clear '+pkg)
shell('wm size 1920x1080')
shell('wm density 420')
shell('settings put secure immersive_mode_confirmations confirmed',check=False)
shell('settings put system accelerometer_rotation 0',check=False)
shell('settings put system user_rotation 1',check=False)
shell('am start -W -n '+pkg+'/.AIRAppEntry')
time.sleep(8)
blocks=re.split(r'(?=add device \d+:)',shell('getevent -pl',check=False))
keyboard=None
for block in blocks:
    m=re.search(r'(/dev/input/event\d+)',block)
    if m and all(token in block for token in ('KEY_RIGHT','KEY_LEFT','KEY_C','KEY_X','KEY_V')):
        keyboard=m.group(1);break
if not keyboard:
    frame('no-keyboard-qa-inconclusive.png')
    raise RuntimeError('No keyboard event device: test infrastructure inconclusive')
def ev(k,on):
    shell(f'sendevent {keyboard} 1 {key[k]} {int(on)}; sendevent {keyboard} 0 0 0')
def tap(k):
    ev(k,True);time.sleep(.08);ev(k,False);time.sleep(.15)
def hold(k,seconds):
    ev(k,True);time.sleep(seconds);ev(k,False);time.sleep(.15)
frame('01-original-intro.png')
tap('X');time.sleep(.8);tap('X');time.sleep(4)
frame('02-authored-world-entry.png')
# Recording uses only standard character controls after QA-only stage entry.
remote='/sdcard/slf-original-'+os.environ['WORLD']+'.mp4'
record=subprocess.Popen(['adb','shell','screenrecord','--size','1920x1080','--bit-rate','6500000','--time-limit','22',remote],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
time.sleep(3)
for _ in range(3):
    hold(os.environ['DIRECTION'],.27);tap('C');time.sleep(.35)
tap('V')
for _ in range(2):
    hold(os.environ['DIRECTION'],.20);tap('C');time.sleep(.35)
record.wait(timeout=38)
frame('03-after-normal-character-input.png')
video=out/'actual-world-gameplay.mp4'
run(['adb','pull',remote,str(video)])
assert video.stat().st_size>10000,'Video missing or too small'
metadata=run(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=width,height,codec_name','-of','default=noprint_wrappers=1',str(video)])
(out/'video_metadata.txt').write_text(metadata)
(out/'provenance.txt').write_text('\n'.join([
    'world='+os.environ['WORLD'],
    'capture=REAL_ANDROID_EMULATOR_SCREENRECORD',
    'apk_sha256='+hashlib.sha256(apk.read_bytes()).hexdigest(),
    'record_sha256='+hashlib.sha256(video.read_bytes()).hexdigest(),
    'original_level_maps_physics_unchanged=yes',
    'qa_test_only_direct_original_level_entry=yes',
    'natural_progression_not_proven=yes',
    'trailer_ready=no_visual_review_required',
    ''
]))
print('VALID REAL VIDEO CAPTURE',str(video),video.stat().st_size,metadata)
