// Copyright 2026 independent Super Limeade Factory Android restoration.
// Unconfigured native extension adapter: fail closed until tested ANE installed.
// The actual Google Play Games SDK implementation MUST be supplied by an ANE;
// no claim of cloud functionality is made by including this source file.
package
{
    import flash.external.ExtensionContext;
    import flash.events.StatusEvent;

    public class PGSNativeTransport implements ICloudSaveTransport
    {
        public static const EXTENSION_ID:String = "com.ramybaheeg.slfport.pgs.savedgames";
        private var context:ExtensionContext;
        private var pending:Function;
        private var pendingType:String;
        private var ready:Boolean = false;

        public function PGSNativeTransport()
        {
            // A missing extension MUST NOT crash ordinary offline play.
            try { context = ExtensionContext.createExtensionContext(EXTENSION_ID, null); }
            catch (error:Error) { context = null; }
            if (context != null)
            {
                context.addEventListener(StatusEvent.STATUS, onStatus);
                try { ready = context.call("supported") === true; }
                catch (error2:Error) { ready = false; }
            }
        }
        public function get available():Boolean { return ready && context != null; }

        public function read(slot:String, completed:Function):void
        {
            if (!available || pending != null) { completed("error", null); return; }
            pending = completed; pendingType = "read";
            try {
                if (context.call("read", slot) !== true) fail("error");
            } catch (error:Error) { fail("error"); }
        }

        public function write(slot:String, snapshot:String, completed:Function):void
        {
            if (!available || pending != null) { completed("error"); return; }
            pending = completed; pendingType = "write";
            try {
                if (context.call("write", slot, snapshot) !== true) fail("error");
            } catch (error:Error) { fail("error"); }
        }

        private function fail(status:String):void
        {
            var callback:Function = pending;
            var kind:String = pendingType;
            pending = null; pendingType = null;
            if (callback != null)
            {
                if (kind == "read") callback(status, null);
                else callback(status);
            }
        }

        // ANE sends JSON {operation, status, payload} in StatusEvent.level.
        // Never accept a stale, unsolicited, or mismatched operation result.
        private function onStatus(event:StatusEvent):void
        {
            if (pending == null) return;
            var data:Object;
            try { data = JSON.parse(event.level); }
            catch (error:Error) { fail("error"); return; }
            if (data == null || data.operation !== pendingType) return;
            var callback:Function = pending;
            var kind:String = pendingType;
            pending = null; pendingType = null;
            if (kind == "read")
                callback(data.status == "ok" || data.status == "empty" ? data.status : "error",
                         data.status == "ok" && data.payload is String ? data.payload as String : null);
            else
                callback(data.status == "ok" || data.status == "conflict" ? data.status : "error");
        }

        public function dispose():void
        {
            if (pending != null) fail("error");
            if (context != null)
            {
                context.removeEventListener(StatusEvent.STATUS, onStatus);
                context.dispose();
                context = null;
            }
            ready = false;
        }
    }
}
