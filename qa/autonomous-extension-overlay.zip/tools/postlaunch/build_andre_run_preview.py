#!/usr/bin/env python3
"""Integrate genuine hand-reviewed André 6-frame artwork in PREVIEW ONLY.

Retains 600x640 sprite atlas, 50x80 frame geometry, 90 unaltered slots,
original collision boundaries and Classic graphics. Does not pretend to be
complete remastered content.
"""
from pathlib import Path
from PIL import Image
import sys

root=Path(__file__).resolve().parents[2]
classic=root/'data/chars_50x50.png'
prototype=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/slf_remaster_pilot/andre_run_6frames_native_exact_50x80_PILOT_NOT_SHIPPED.png')
output=root/'data/remaster_prototype/chars_andre_run_preview.png'
a=Image.open(classic).convert('RGBA')
b=Image.open(prototype).convert('RGBA')
assert a.size==(600,640) and b.size==(300,80)
for i in range(6):
    frame=b.crop((i*50,0,(i+1)*50,80))
    alpha=frame.getchannel('A')
    assert alpha.getbbox() is not None, i
    assert alpha.getextrema()[0]==0, i
    a.paste(frame, ((6+i)*50,0))
output.parent.mkdir(parents=True,exist_ok=True)
a.save(output,optimize=True)
with Image.open(output) as c:
    assert c.size==(600,640)
    assert sum(c.crop((i*50,0,(i+1)*50,80)).tobytes()!=Image.open(classic).convert('RGBA').crop((i*50,0,(i+1)*50,80)).tobytes() for i in range(6,12))==6
print('PREVIEW ONLY: six Andre run frames installed without changing other sprite slots:',output)
