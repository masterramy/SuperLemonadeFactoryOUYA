#!/usr/bin/env python3
"""Six native animation cells from inspected Liselot reference, Preview only."""
from PIL import Image
from scipy.ndimage import label, find_objects
import numpy as np
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
source=Image.open('/mnt/data/a_large_pixel_art_sprite_sheet_on_a_transparent_ch.png').convert('RGBA')
old=Image.open(ROOT/'data/remaster_prototype/chars_andre_run_preview.png').convert('RGBA')
colors=np.asarray(source)
region=colors[155:310,:,3]>40
labeled,n=label(region)
comps=[]
for i,e in enumerate(find_objects(labeled),1):
    if e is None: continue
    y,x=e
    area=int((labeled[e]==i).sum())
    if area>900:comps.append((x.start,x.stop,155+y.start,155+y.stop,area))
comps.sort(key=lambda c:c[0])
assert len(comps)==12 and all(comps[i][1]<comps[i+1][0] for i in range(11)),comps
for i,(x0,x1,y0,y1,_) in enumerate(comps[:6]):
    cut=source.crop((x0,y0,x1,y1))
    target_h=43
    target_w=round(cut.width*target_h/cut.height)
    if target_w>38:target_w=38;target_h=round(cut.height*target_w/cut.width)
    sprite=cut.resize((target_w,target_h),Image.Resampling.NEAREST)
    tile=Image.new('RGBA',(50,80),(0,0,0,0))
    tile.alpha_composite(sprite,((50-target_w)//2,80-target_h))
    slot=12+i;x=slot%12*50;y=slot//12*80
    old.paste(tile,(x,y))
output=ROOT/'data/remaster_prototype/chars_two_heroes_run_preview.png'
old.save(output,optimize=True)
print('PREVIEW ONLY, original game geometry retained:',output)
