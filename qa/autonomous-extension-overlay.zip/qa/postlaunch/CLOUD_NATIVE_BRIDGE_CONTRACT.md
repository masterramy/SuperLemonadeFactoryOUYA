# PGSv2 Saved Games native extension gate — NOT implemented Google cloud

`CloudSyncCoordinator` is the real AS3 no-loss, explicit-consent, conflict-aware orchestration. `PGSNativeTransport` is the fail-closed AS3 native-extension endpoint. Neither provides Google account sign-in by itself.

Required native extension ID: `com.ramybaheeg.slfport.pgs.savedgames`. An actual Android-native FREExtension must implement:

* `supported(): Boolean` — true **only after** Google Play Games SDK v2 authentication and local Play Games configuration are valid, with Saved Games enabled.
* `read(slot): Boolean` — accepted work dispatch, followed by `StatusEvent.STATUS` with `event.level` JSON `{ "operation":"read", "status":"ok|empty|error", "payload":"..." }`. Do not claim empty on network errors.
* `write(slot,payload): Boolean` — accepted dispatch, followed by `{ "operation":"write", "status":"ok|conflict|error" }`. A conflict must result in a fresh read, not last-writer-wins.

The native code **must never** silently auto-sign-in, fabricate successful writes, or claim a cache hit is server persistence. Configure Game projects / Saved Games, OAuth app SHA-1 identity and Play signing cert before enabling the game UI; verify on two physical signed-in devices, including offline/online and cross-device conflicts. The standalone `.dev` package uses disposable per-run signatures and is **not** an OAuth-certified PGS client. Do not ask the owner for personal signing passwords.

Commercial maintained candidate: distriqt GameServices ANE, dependent on the ANE-AndroidSupport and Google Play Services Gamesv2 ANEs. Its API differs from this self-owned contract; if licensed, write a separate distriqt adapter against the exact installed AIR SDK/library rather than pretending this extension ID exists.

No extension ID or permissions should be added to the shipping AIR `application.xml` until the native library is present, tested, and authorized. Current game remains completely offline.
